# emp-mean-app
Employee Directory App - MEAN Stack by Anirudh Erabelly
